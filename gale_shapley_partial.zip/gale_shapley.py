import partial_orders

def gale_shapley_loop(proposers_prefs, receivers_partial_prefs, opt_matching, set_proposers):
    for proposer, receivers in proposers_prefs.items():
        proposer_index = set_proposers.index(proposer)

        # If the proposer is not yet matched
        if opt_matching[proposer] == "None":
            for receiver in receivers:
                # If the receiver is already matched with another agent
                if (any(receiver in receivers_matching for receivers_matching in opt_matching.values())):
                    receiver_prefs_matrix = receivers_partial_prefs[receiver]
                    for proposer_matching, receiver_matching in opt_matching.items():
                        if receiver_matching == receiver:
                            proposer_matching = proposer_matching
                            proposer_matching_index = set_proposers.index(proposer_matching)
                            break

                    # Comparison of the proposer with the matched agent w.r.t the receiver's preferences
                    if receiver_prefs_matrix[proposer_index, proposer_matching_index] == 1:
                        opt_matching[proposer] = receiver
                        opt_matching[proposer_matching] = "None"
                        break

                # If the receiver is not yet matched
                else:
                    opt_matching[proposer] = receiver
                    break

        # If after the iterations, there is still no stable matching found
        if opt_matching[proposer] == "None":
            print("A stable matching could not be found")

    return opt_matching

def gale_shapley_partial(proposers_prefs, receivers_partial_prefs):
    # Definition of the optimal stable matching
    proposer_opt = {proposer : "None" for proposer in proposers_prefs}
    all_proposers = list(proposers_prefs.keys())

    while any("None" in prefs_list for prefs_list in proposer_opt.values()):
        proposer_opt = gale_shapley_loop(proposers_prefs,
                                         receivers_partial_prefs,
                                         proposer_opt,
                                         all_proposers)

    return proposer_opt


def gale_shapley_all_partial_loop(proposers_partial_prefs, receivers_partial_prefs, set_proposers, set_receivers, positive_dic, opt_matching):
    for proposer, receivers_matrix in proposers_partial_prefs.items():
        proposer_index = set_proposers.index(proposer)
        positive_dic[proposer] = partial_orders.count_positive_matrix(receivers_matrix)

        # If the proposer is not yet matched
        if opt_matching[proposer] == "None":
            for i in set_receivers:
                # We find the most relevant receiver in the partial order preferences list of the proposer
                receiver_index = partial_orders.choose_receiver(positive_dic[proposer])
                positive_dic[proposer][receiver_index] = -1
                receiver = set_receivers[receiver_index]

                # If the receiver is already matched with another agent
                if (any(receiver in receivers_matching for receivers_matching in opt_matching.values())):
                    receiver_prefs_matrix = receivers_partial_prefs[receiver]
                    for proposer_matching, receiver_matching in opt_matching.items():
                        if receiver_matching == receiver:
                            proposer_matching = proposer_matching
                            proposer_matching_index = set_proposers.index(proposer_matching)
                            break

                    # Comparison of the proposer with the matched agent w.r.t the receiver's preferences
                    if receiver_prefs_matrix[proposer_index, proposer_matching_index] == 1:
                        opt_matching[proposer] = receiver
                        opt_matching[proposer_matching] = "None"
                        break

                # If the receiver is not yet matched
                else:
                    opt_matching[proposer] = receiver
                    break

        # If after the iterations, there is still no stable matching found
        if opt_matching[proposer] == "None":
            print("A stable matching could not be found")

    return opt_matching


def gale_shapley_all_partial(proposers_partial_prefs, receivers_partial_prefs):
    # Definition of the optimal stable matching
    all_proposers = list(proposers_partial_prefs.keys())
    all_receivers = list(receivers_partial_prefs.keys())
    proposer_opt = {proposer : "None" for proposer in all_proposers}
    positive_dic = {proposer: "None" for proposer in all_proposers}

    while any("None" in prefs_list for prefs_list in proposer_opt.values()):
        proposer_opt = gale_shapley_all_partial_loop(proposers_partial_prefs,
                                                     receivers_partial_prefs,
                                                     all_proposers,
                                                     all_receivers,
                                                     positive_dic,
                                                     proposer_opt)

    return proposer_opt

