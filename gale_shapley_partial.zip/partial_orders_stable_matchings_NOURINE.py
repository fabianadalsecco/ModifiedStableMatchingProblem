import numpy as np
import gale_shapley
import partial_orders
#from matching.games import StableMarriage

proposers_preferences_1 = {
    '1': ['D', 'A', 'C', 'B'],
    '2': ['B', 'D', 'A', 'C'],
    '3': ['D', 'B', 'C', 'A'],
    '4': ['D', 'B', 'C', 'A'],
}

proposers_preferences_2 = {
    '1': ['B', 'A', 'C', 'D'],  # modified
    '2': ['B', 'D', 'A', 'C'],
    '3': ['B', 'D', 'C', 'A'],  # modified
    '4': ['D', 'A', 'C', 'B'],  # modified
}

receivers_preferences_1 = {
    'A': ['2', '3', '1', '4'],
    'B': ['3', '2', '4', '1'],
    'C': ['4', '1', '3', '2'],
    'D': ['3', '2', '1', '4'],
}

receivers_preferences_2 = {
    'A': ['1', '2', '4', '3'],  # modified
    'B': ['4', '1', '3', '2'],  # modified
    'C': ['4', '1', '3', '2'],
    'D': ['1', '2', '4', '3'],  # modified
}

# Original instance: proposers_preferences and receivers_preferences_1
partial_order_matrices_receivers_1 = partial_orders.construct_partial_order_matrix(receivers_preferences_1)
partial_order_matrices_proposers_1 = partial_orders.construct_partial_order_matrix(proposers_preferences_1)
stable_matching_all_partial_1 = gale_shapley.gale_shapley_all_partial(partial_order_matrices_proposers_1, partial_order_matrices_receivers_1)
print(f"Optimal stable matching for the proposers in instance (0,0): \n {stable_matching_all_partial_1}\n")

# Combined instance: proposers_preferences and (receivers_preferences_1 + receivers_preferences_2)
partial_order_matrices_receivers_12 = partial_orders.construct_partial_order_matrix(receivers_preferences_1, receivers_preferences_2)
stable_matching_all_partial_12 = gale_shapley.gale_shapley_all_partial(partial_order_matrices_proposers_1, partial_order_matrices_receivers_12)
print(f"Optimal stable matching for the proposers in combined instance (0,n): \n {stable_matching_all_partial_12}\n")

# Combined instance: (proposers_preferences_1 + proposers_preferences_2) and (receivers_preferences_1 + receivers_preferences_2)
partial_order_matrices_proposers_12 = partial_orders.construct_partial_order_matrix(proposers_preferences_1, proposers_preferences_2)
stable_matching_all_partial = gale_shapley.gale_shapley_all_partial(partial_order_matrices_proposers_12, partial_order_matrices_receivers_12)
print(f"Optimal stable matching for the proposers in combined instance (n,n): \n {stable_matching_all_partial}")
